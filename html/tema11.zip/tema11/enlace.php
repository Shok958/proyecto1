<?php 
	class Enlace
	{
		public $href;
		public $texto;

		public function __construct($texto,$href){
			$this->texto = $texto;
			$this->href = $href;
		}

		public function mostrar(){
			return "<a href=".$this->href.">".$this->texto."</a>";
		}
	}

 ?>
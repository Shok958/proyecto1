<?php 
	include "freelance.php";

	$pepe = new Freelance("Pepe");
	$pepe->desarrollar();
 ?>